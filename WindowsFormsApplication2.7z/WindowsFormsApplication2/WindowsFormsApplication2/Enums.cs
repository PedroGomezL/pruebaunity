﻿namespace WindowsFormsApplication2
{
    public enum NivelLog
    {
        ///<summary>Nivel de log de tipo Informativo.</summary>
        Info,
        ///<summary>Nivel de log de tipo Error.</summary>
        Error,
        ///<summary>Nivel de log de tipo Depuración.</summary>
        Debug,
        ///<summary>Nivel de log de tipo Advertencia.</summary>
        Warn,
        ///<summary>Sin nivel de log.</summary>
        Log,
        ///<summary>Nivel de log de tipo Fatal.</summary>
        Fatal
    }
}
