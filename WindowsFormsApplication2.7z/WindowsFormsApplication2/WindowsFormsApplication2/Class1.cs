﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using System.Diagnostics;
using System.Reflection;

namespace WindowsFormsApplication2
{
    class Class1
    {
        private const int KINT_NUMERO_METODO_ORIGEN = 0;
        private const int KINT_NUMERO_METODO_MOSTRAR = 2;

        ///<summary>Método que registra los niveles de error</summary>
        ///<param name="pNivel">Nivel del log</param>
        ///<param name="pModulo">Modulo</param>
        ///<param name="pFuncion">Función</param>
        ///<param name="pMensaje">Mensjae</param>
        ///<remarks>
        ///<list type = "bullet">
        ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        ///<item><FecCrea>09/05/2016</FecCrea></item>
        ///</list>
        ///</remarks>
        public static void RegistrarLog(string pNivel, string pModulo, string pFuncion, string pMensaje)
        {
            try
            {
                if (pNivel == "D")
                    Log4Net.InvokeAppendLog(pModulo, pMensaje);
                else if (pNivel == "E")
                    Log4Net.InvokeAppendLogError(pModulo, pMensaje);
                else if (pNivel == "I")
                    Log4Net.InvokeAppendLogInfo(pModulo, pMensaje);
                else if (pNivel == "W")
                    Log4Net.InvokeAppendLogWarn(pModulo, pMensaje);
                else
                    Log4Net.InvokeAppendLog(pModulo, pMensaje);
            }
            catch
            {
                throw;
            }
        }

        ///<summary>Método que registra los niveles de error</summary>
        ///<param name="nivel">Nivel del log</param>
        ///<param name="pModulo">Modulo</param>
        ///<param name="pFuncion">Función</param>
        ///<param name="pMensaje">Mensjae</param>
        ///<remarks>
        ///<list type = "bullet">
        ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        ///<item><FecCrea>09/05/2016</FecCrea></item>
        ///</list>
        ///</remarks>
        public static void RegistrarLog(NivelLog nivel, string pModulo, string pFuncion, string pMensaje)
        {
            try
            {
                if (nivel == NivelLog.Debug)
                    Log4Net.InvokeAppendLog(pModulo, pMensaje);
                else if (nivel == NivelLog.Error)
                    Log4Net.InvokeAppendLogError(pModulo, pMensaje);
                else if (nivel == NivelLog.Info)
                    Log4Net.InvokeAppendLogInfo(pModulo, pMensaje);
                else if (nivel == NivelLog.Warn)
                    Log4Net.InvokeAppendLogWarn(pModulo, pMensaje);
                else
                    Log4Net.InvokeAppendLog(pModulo, pMensaje);
            }
            catch
            {
                throw;
            }
        }

        ///<summary>Método que registra los niveles de error</summary>
        ///<param name="pNivel">Nivel del log</param>
        ///<param name="pModulo">Modulo</param>
        ///<param name="pFuncion">Función</param>
        ///<param name="pMensaje">Mensjae</param>
        ///<param name="ex">Objeto de tipo Exception que contiene el error</param>
        ///<remarks>
        ///<list type = "bullet">
        ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        ///<item><FecCrea>09/05/2016</FecCrea></item>
        ///</list>
        ///</remarks>
        public static void RegistrarLog(string pNivel, string pModulo, string pFuncion, string pMensaje, Exception ex)
        {
            try
            {
                if (pNivel == "D")
                    Log4Net.InvokeAppendLog(pModulo, pMensaje, ex);
                else if (pNivel == "E")
                    Log4Net.InvokeAppendLogError(pModulo, pMensaje, ex);
                else if (pNivel == "I")
                    Log4Net.InvokeAppendLogInfo(pModulo, pMensaje, ex);
                else if (pNivel == "W")
                    Log4Net.InvokeAppendLogWarn(pModulo, pMensaje, ex);
                else
                    Log4Net.InvokeAppendLog(pModulo, pMensaje, ex);
            }
            catch
            {
                throw;
            }
        }

        ///<summary>Método que registra los niveles de error</summary>
        ///<param name="nivel">Nivel del log</param>
        ///<param name="pModulo">Modulo</param>
        ///<param name="pFuncion">Función</param>
        ///<param name="pMensaje">Mensjae</param>
        ///<param name="ex">Objeto de tipo Exception que contiene el error</param>
        ///<remarks>
        ///<list type = "bullet">
        ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        ///<item><FecCrea>09/05/2016</FecCrea></item>
        ///</list>
        ///</remarks>
        public static void RegistrarLog(NivelLog nivel, string pModulo, string pFuncion, string pMensaje, Exception ex)
        {
            try
            {
                if (nivel == NivelLog.Debug)
                    Log4Net.InvokeAppendLog(pModulo, pMensaje, ex);
                else if (nivel == NivelLog.Error)
                    Log4Net.InvokeAppendLogError(pModulo, pMensaje, ex);
                else if (nivel == NivelLog.Info)
                    Log4Net.InvokeAppendLogInfo(pModulo, pMensaje, ex);
                else if (nivel == NivelLog.Warn)
                    Log4Net.InvokeAppendLogWarn(pModulo, pMensaje, ex);
                else
                    Log4Net.InvokeAppendLog(pModulo, pMensaje, ex);
            }
            catch
            {
                throw;
            }
        }

        ///<summary>Método que registra los niveles de error</summary>
        ///<param name="nivel">Nivel del log</param>
        ///<param name="pMensaje">Mensaje</param>
        ///<remarks>
        ///<list type = "bullet">
        ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        ///<item><FecCrea>09/05/2016</FecCrea></item>
        ///</list>
        ///</remarks>
        public static void RegistrarLog(NivelLog nivel, string pMensaje)
        {
            try
            {
                string nombreMetodo = "";

                try
                {
                    nombreMetodo = "[" + ObtenerRutaNombreMetodoEjecutado(KINT_NUMERO_METODO_MOSTRAR).Trim() + "] ";
                }
                catch { }

                if (nivel == NivelLog.Debug)
                    Log4Net.InvokeAppendLog(nombreMetodo + pMensaje);
                else if (nivel == NivelLog.Error)
                    Log4Net.InvokeAppendLogError(nombreMetodo + pMensaje);
                else if (nivel == NivelLog.Info)
                    Log4Net.InvokeAppendLogInfo(nombreMetodo + pMensaje);
                else if (nivel == NivelLog.Warn)
                    Log4Net.InvokeAppendLogWarn(nombreMetodo + pMensaje);
                else
                    Log4Net.InvokeAppendLog(nombreMetodo + pMensaje);
            }
            catch
            {
                throw;
            }
        }

        ///<summary>Método que registra los niveles de error</summary>
        ///<param name="nivel">Nivel del log</param>
        ///<param name="pMensaje">Mensjae</param>
        ///<param name="ex">Objeto de tipo Exception que contiene el error</param>
        ///<remarks>
        ///<list type = "bullet">
        ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        ///<item><FecCrea>09/05/2016</FecCrea></item>
        ///</list>
        ///</remarks>
        public static void RegistrarLog(NivelLog nivel, string pMensaje, Exception ex)
        {
            try
            {
                string nombreMetodo = "";

                try
                {
                    nombreMetodo = "[" + ObtenerRutaNombreMetodoEjecutado(KINT_NUMERO_METODO_MOSTRAR).Trim() + "] ";
                }
                catch { }

                if (nivel == NivelLog.Debug)
                    Log4Net.InvokeAppendLog(nombreMetodo + pMensaje, ex);
                else if (nivel == NivelLog.Error)
                    Log4Net.InvokeAppendLogError(nombreMetodo + pMensaje, ex);
                else if (nivel == NivelLog.Info)
                    Log4Net.InvokeAppendLogInfo(nombreMetodo + pMensaje, ex);
                else if (nivel == NivelLog.Warn)
                    Log4Net.InvokeAppendLogWarn(nombreMetodo + pMensaje, ex);
                else
                    Log4Net.InvokeAppendLog(nombreMetodo + pMensaje, ex);
            }
            catch
            {
                throw;
            }
        }

        ///<summary>Método que registra los niveles de error</summary>
        ///<param name="nivel">Nivel del log</param>
        ///<param name="ex">Objeto de tipo Exception que contiene el error</param>
        ///<remarks>
        ///<list type = "bullet">
        ///<item><CreadoPor>Edgard M. Márquez A.</CreadoPor></item>
        ///<item><FecCrea>29/08/2017</FecCrea></item>
        ///</list>
        ///</remarks>
        public static void RegistrarLog(NivelLog nivel, Exception ex)
        {
            RegistrarLog(nivel, "", ex);
        }

        private static string ObtenerRutaNombreMetodoEjecutado(int valor)
        {
            StackTrace trace = new StackTrace(StackTrace.METHODS_TO_SKIP + valor);
            StackFrame frame = trace.GetFrame(KINT_NUMERO_METODO_ORIGEN);
            System.Diagnostics.StackTrace t = new System.Diagnostics.StackTrace(frame);

            return t.ToString();
        }

        private static string ObtenerNombreMetodoEjecutado(int valor)
        {
            StackTrace trace = new StackTrace(StackTrace.METHODS_TO_SKIP + valor);
            StackFrame frame = trace.GetFrame(KINT_NUMERO_METODO_ORIGEN);
            MethodBase caller = frame.GetMethod();

            return caller.ToString();
        }
    }
}
