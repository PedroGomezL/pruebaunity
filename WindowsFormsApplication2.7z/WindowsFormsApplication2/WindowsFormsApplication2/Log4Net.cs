﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication2
{
    public class Log4Net
    {
        #region Miembros
        private static readonly ILog logger = LogManager.GetLogger(typeof(Log4Net));
        #endregion

        #region Contructores
        static Log4Net()
        {
            XmlConfigurator.Configure();
        }
        #endregion

        #region Metodos
        /// <summary>Metodo que escribe segun el nivel del log</summary>
        /// <param name="logLevel">Nivel de log</param>
        /// <param name="log">Texto del log</param>
        public static void WriteLog(NivelLog logLevel, String log)
        {
            switch (logLevel)
            {
                case NivelLog.Debug:
                default:
                    if (logger.IsDebugEnabled)
                        logger.Debug(log);
                    break;
                case NivelLog.Error:
                    if (logger.IsErrorEnabled || logger.IsInfoEnabled)
                        logger.Error(log);
                    break;
                case NivelLog.Fatal:
                    if (logger.IsFatalEnabled)
                        logger.Fatal(log);
                    break;
                case NivelLog.Info:
                    if (logger.IsInfoEnabled)
                        logger.Info(log);
                    break;
                case NivelLog.Warn:
                    if (logger.IsWarnEnabled)
                        logger.Warn(log);
                    break;
            }
        }


        /// <summary>Metodo que escribe segun el nivel del log</summary>
        /// <param name="logLevel">Nivel de log</param>
        /// <param name="log">Texto del log</param>
        /// <param name="ex">Excepción</param>
        public static void WriteLog(NivelLog logLevel, String log, Exception ex)
        {
            switch (logLevel)
            {
                case NivelLog.Debug:
                default:
                    if (logger.IsDebugEnabled)
                        logger.Debug(log, ex);
                    break;
                case NivelLog.Error:
                    if (logger.IsErrorEnabled || logger.IsInfoEnabled)
                        logger.Error(log, ex);
                    break;
                case NivelLog.Fatal:
                    if (logger.IsFatalEnabled)
                        logger.Fatal(log, ex);
                    break;
                case NivelLog.Info:
                    if (logger.IsInfoEnabled)
                        logger.Info(log, ex);
                    break;
                case NivelLog.Warn:
                    if (logger.IsWarnEnabled)
                        logger.Warn(log, ex);
                    break;
            }
        }

        /// <summary>Escribe un nivel de tipo Debug por modulo.</summary>
        /// <param name="modulo">Modulo</param>
        /// <param name="msg">Mensaje</param>
        public static void InvokeAppendLog(string modulo, string msg)
        {
            Log4Net.WriteLog(NivelLog.Debug, "[" + modulo + "] " + msg);
        }

        /// <summary>Escribe un nivel de tipo Debug por modulo.</summary>
        /// <param name="modulo">Modulo</param>
        /// <param name="msg">Mensaje</param>
        /// <param name="ex">Excepción</param>
        public static void InvokeAppendLog(string modulo, string msg, Exception ex)
        {
            Log4Net.WriteLog(NivelLog.Debug, "[" + modulo + "] " + msg, ex);
        }

        /// <summary>Escribe un nivel de tipo Debug por modulo.</summary>
        /// <param name="msg">Mensaje</param>
        /// <param name="ex">Excepción</param>
        public static void InvokeAppendLog(string msg, Exception ex)
        {
            Log4Net.WriteLog(NivelLog.Debug, msg, ex);
        }

        /// <summary>Escribe un nivel de tipo Debug por modulo.</summary>
        /// <param name="msg">Mensaje</param>
        public static void InvokeAppendLog(string msg)
        {
            Log4Net.WriteLog(NivelLog.Debug, msg);
        }

        /// <summary>Escribe un nivel de tipo error por modulo</summary>
        /// <param name="modulo">Modulo</param>
        /// <param name="msg">Mensaje</param>
        public static void InvokeAppendLogError(string modulo, string msg)
        {
            Log4Net.WriteLog(NivelLog.Error, "[" + modulo + "] " + msg);
        }

        /// <summary>Escribe un nivel de tipo error por modulo.</summary>
        /// <param name="modulo">Modulo</param>
        /// <param name="msg">Mensaje</param>
        /// <param name="ex">Excepción</param>
        public static void InvokeAppendLogError(string modulo, string msg, Exception ex)
        {
            Log4Net.WriteLog(NivelLog.Error, "[" + modulo + "] " + msg, ex);
        }

        /// <summary>Escribe un nivel de tipo error por modulo.</summary>
        /// <param name="msg">Mensaje</param>
        public static void InvokeAppendLogError(string msg)
        {
            Log4Net.WriteLog(NivelLog.Error, msg);
        }

        /// <summary>Escribe un nivel de tipo error por modulo.</summary>
        /// <param name="msg">Mensaje</param>
        /// <param name="ex">Excepción</param>
        public static void InvokeAppendLogError(string msg, Exception ex)
        {
            Log4Net.WriteLog(NivelLog.Error, msg, ex);
        }

        /// <summary>Escribe un nivel de tipo info por modulo</summary>
        /// <param name="modulo"></param>
        /// <param name="msg"></param>
        public static void InvokeAppendLogInfo(string modulo, string msg)
        {
            Log4Net.WriteLog(NivelLog.Info, "[" + modulo + "] " + msg);
        }

        /// <summary>Escribe un nivel de tipo info por modulo.</summary>
        /// <param name="modulo">Modulo</param>
        /// <param name="msg">Mensaje</param>
        /// <param name="ex">Excepción</param>
        public static void InvokeAppendLogInfo(string modulo, string msg, Exception ex)
        {
            Log4Net.WriteLog(NivelLog.Info, "[" + modulo + "] " + msg, ex);
        }

        /// <summary>Escribe un nivel de tipo info por modulo.</summary>
        /// <param name="msg">Mensaje</param>
        /// <param name="ex">Excepción</param>
        public static void InvokeAppendLogInfo(string msg, Exception ex)
        {
            Log4Net.WriteLog(NivelLog.Info, msg, ex);
        }

        /// <summary>Escribe un nivel de tipo info por modulo.</summary>
        /// <param name="msg">Mensaje</param>
        public static void InvokeAppendLogInfo(string msg)
        {
            Log4Net.WriteLog(NivelLog.Info, msg);
        }

        /// <summary>Escribe un nivel de tipo Warn por modulo.</summary>
        /// <param name="modulo">Modulo</param>
        /// <param name="msg">Mensaje</param>
        public static void InvokeAppendLogWarn(string modulo, string msg)
        {
            Log4Net.WriteLog(NivelLog.Warn, "[" + modulo + "] " + msg);
        }

        /// <summary>Escribe un nivel de tipo Warn por modulo.</summary>
        /// <param name="modulo">Modulo</param>
        /// <param name="msg">Mensaje</param>
        /// <param name="ex">Excepción</param>
        public static void InvokeAppendLogWarn(string modulo, string msg, Exception ex)
        {
            Log4Net.WriteLog(NivelLog.Warn, "[" + modulo + "] " + msg, ex);
        }

        /// <summary>Escribe un nivel de tipo Warn por modulo.</summary>
        /// <param name="msg">Mensaje</param>
        /// <param name="ex">Excepción</param>
        public static void InvokeAppendLogWarn(string msg, Exception ex)
        {
            Log4Net.WriteLog(NivelLog.Warn, msg, ex);
        }

        /// <summary>Escribe un nivel de tipo Warn por modulo.</summary>
        /// <param name="msg">Mensaje</param>
        public static void InvokeAppendLogWarn(string msg)
        {
            Log4Net.WriteLog(NivelLog.Warn, msg);
        }

        #endregion
    }
}
