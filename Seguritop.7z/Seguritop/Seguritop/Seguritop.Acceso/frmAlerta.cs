﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seguritop.Acceso
{
    public partial class frmAlerta : Form
    {
        public frmAlerta()
        {
            InitializeComponent();
        }

        private void frmAlerta_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private bool existeSolcitud()
        {
            try
            {   // Open the text file using a stream reader.
                var existe = false;
                string appPath = Path.GetDirectoryName(Application.ExecutablePath);
                using (StreamReader sr = new StreamReader(@appPath + "\\solicitud.txt"))
                {
                    // Read the stream to a string, and write the string to the console.
                    String line = sr.ReadToEnd();
                    if (line.Contains("1"))
                    {
                        return true;
                    }
                }
                return existe;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void limpiarSolcitud()
        {
            string appPath = Path.GetDirectoryName(Application.ExecutablePath);
            using (StreamWriter file = new StreamWriter(@appPath + "\\solicitud.txt"))
            {
                file.WriteLine("");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (existeSolcitud())
            {
                timer1.Enabled = false;
                MessageBox.Show("Un cliente se ha registrado, ya puede permitirle el acceso.\n" + 
                    "Recuerde presionar el boton ACEPTAR y verificar que el cliente cierre la puerta.", "Atención!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                limpiarSolcitud();
                timer1.Enabled = true;
            }

            string texto = lblMensaje.Text;
            if (texto == "Esperando solicitud de acceso...")
            {
                lblMensaje.Text = "Esperando solicitud de acceso";
            }
            else if (texto == "Esperando solicitud de acceso")
            {
                lblMensaje.Text = "Esperando solicitud de acceso.";
            }
            else if (texto == "Esperando solicitud de acceso.")
            {
                lblMensaje.Text = "Esperando solicitud de acceso..";
            }
            else if (texto == "Esperando solicitud de acceso..")
            {
                lblMensaje.Text = "Esperando solicitud de acceso...";
            }


        }
    }
}
