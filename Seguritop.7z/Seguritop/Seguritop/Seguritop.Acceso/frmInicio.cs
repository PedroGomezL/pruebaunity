﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seguritop.Acceso
{
    public partial class frmInicio : Form
    {
        public frmInicio()
        {
            InitializeComponent();
        }

        private void btnIdentificacion_Click(object sender, EventArgs e)
        {
            var frm = new frmIdentificacion();
            frm.Show();
            this.Close();
        }

        private void btnAlerta_Click(object sender, EventArgs e)
        {
            var frm = new frmAlerta();
            frm.Show();
            this.Close();
        }
    }
}
