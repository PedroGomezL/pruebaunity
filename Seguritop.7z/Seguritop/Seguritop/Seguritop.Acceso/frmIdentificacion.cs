﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Seguritop.Acceso
{
    public partial class frmIdentificacion : Form
    {
        public frmIdentificacion()
        {
            InitializeComponent();
        }

        private void enviarSolicitud()
        {
            string appPath = Path.GetDirectoryName(Application.ExecutablePath);
            using (StreamWriter file = new StreamWriter(@appPath + "\\solicitud.txt"))
            {
                file.WriteLine("1");
            }

            //string lines = "1";
            //System.IO.StreamWriter file = new System.IO.StreamWriter("c:\\test.txt");
            //file.WriteLine(lines);
            //file.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            enviarSolicitud();
        }
    }
}
