﻿namespace Seguritop.Acceso
{
    partial class frmInicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInicio));
            this.btnIdentificacion = new System.Windows.Forms.Button();
            this.btnAlerta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnIdentificacion
            // 
            this.btnIdentificacion.BackColor = System.Drawing.SystemColors.Control;
            this.btnIdentificacion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIdentificacion.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnIdentificacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIdentificacion.ForeColor = System.Drawing.Color.Black;
            this.btnIdentificacion.Image = ((System.Drawing.Image)(resources.GetObject("btnIdentificacion.Image")));
            this.btnIdentificacion.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnIdentificacion.Location = new System.Drawing.Point(46, 32);
            this.btnIdentificacion.Name = "btnIdentificacion";
            this.btnIdentificacion.Size = new System.Drawing.Size(189, 151);
            this.btnIdentificacion.TabIndex = 0;
            this.btnIdentificacion.Text = "Identificación";
            this.btnIdentificacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnIdentificacion.UseVisualStyleBackColor = false;
            this.btnIdentificacion.Click += new System.EventHandler(this.btnIdentificacion_Click);
            // 
            // btnAlerta
            // 
            this.btnAlerta.BackColor = System.Drawing.SystemColors.Control;
            this.btnAlerta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlerta.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnAlerta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAlerta.ForeColor = System.Drawing.Color.Black;
            this.btnAlerta.Image = ((System.Drawing.Image)(resources.GetObject("btnAlerta.Image")));
            this.btnAlerta.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAlerta.Location = new System.Drawing.Point(254, 32);
            this.btnAlerta.Name = "btnAlerta";
            this.btnAlerta.Size = new System.Drawing.Size(189, 151);
            this.btnAlerta.TabIndex = 1;
            this.btnAlerta.Text = "Alertas de Ingreso";
            this.btnAlerta.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAlerta.UseVisualStyleBackColor = false;
            this.btnAlerta.Click += new System.EventHandler(this.btnAlerta_Click);
            // 
            // frmInicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 212);
            this.Controls.Add(this.btnAlerta);
            this.Controls.Add(this.btnIdentificacion);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmInicio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = ":: Securitop ::";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnIdentificacion;
        private System.Windows.Forms.Button btnAlerta;
    }
}